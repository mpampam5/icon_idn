<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tb_contoh extends Backend{

  private $table = "tb_contoh";

  public function __construct()
  {
    parent::__construct();
    $this->load->library(array('datatables'));
    $this->load->model('Tb_contoh_model','model');
  }




  function _rules()
  {
     $this->form_validation->set_rules("nama","Nama","trim|xss_clean|required");
     $this->form_validation->set_rules("alamat","Alamat","trim|xss_clean|required");
     $this->form_validation->set_error_delimiters('<p class="form-text text-danger">','</p>');
   }





  function index()
  {
    $this->temp_backend->set_title('Tb Contoh');
    $this->temp_backend->view('content/tb_contoh/index');
  }





  function json()
  {
    header('Content-Type: application/json');
    echo $this->model->json();
  }

  function detail($id)
  {
    if ($row = $this->model->get_where($this->table,['id_contoh'=>$id])) {
      $this->temp_backend->set_title('Tb Contoh');
        $data = [
                  "nama"        => $row->nama,
                  "alamat"      => $row->alamat
                ];

      $this->temp_backend->view('content/tb_contoh/detail',$data);
    }else {
      $this->_error404();
    }
  }






  function add()
  {
      $this->temp_backend->set_title('Tb Contoh');
        $data = [
                  "button"      => "tambah",
                  "action"      => site_url("backend/tb_contoh/add_action"),
                  "nama"        => set_value("nama"),
                  "alamat"      => set_value("alamat"),
                ];

      $this->temp_backend->view('content/tb_contoh/form',$data);
  }





  function add_action()
  {
    if ($this->input->is_ajax_request()) {
        $json = array('success'=>false, 'alert'=>array());
        $this->_rules();
        if ($this->form_validation->run()) {
          $insert = [
                      "nama"    =>  $this->input->post("nama",true),
                      "alamat"  =>  $this->input->post("alamat",true)
                    ];

          if ($this->model->get_insert($this->table,$insert)) {
            $json['alert']   = '<div id="alert" class="alert alert-success">
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                  <i class="fa fa-check"></i> Berhasil Menambahkan.
                                <div>';
          }else {
            $json['alert']   = '<div id="alert" class="alert alert-danger">
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                  <i class="fa fa-close"></i> Gagal Menambahkan.
                                <div>';
          }

          $json['success'] = true;
        }else {
          foreach ($_POST as $key => $value)
            {
              $json['alert'][$key] = form_error($key);
            }
        }

        echo json_encode($json);
    }
  }





  function update($id)
  {
    if ($row = $this->model->get_where($this->table,['id_contoh'=>$id])) {
      $this->temp_backend->set_title('Tb Contoh');

        $data = [
                  "button"      => "edit",
                  "action"      => site_url("backend/tb_contoh/update_action/$id"),
                  "nama"        => set_value("nama",$row->nama),
                  "alamat"      => set_value("alamat",$row->alamat),
                ];

      $this->temp_backend->view('content/tb_contoh/form',$data);
    }else {
      $this->_error404();
    }
  }





  function update_action($id)
  {
    if ($this->input->is_ajax_request()) {
        $json = array('success'=>false, 'alert'=>array());
        $this->_rules();
        if ($this->form_validation->run()) {
          $update = [
                      "nama"    =>  $this->input->post("nama",true),
                      "alamat"  =>  $this->input->post("alamat",true)
                    ];

          if ($this->model->get_update($this->table,$update,["id_contoh"=>$id])) {
            $json['alert']   = '<div id="alert" class="alert alert-success">
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                  <i class="fa fa-check"></i> Berhasil Mengedit.
                                <div>';
          }else {
            $json['alert']   = '<div id="alert" class="alert alert-danger">
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                  <i class="fa fa-close"></i> Gagal Mengedit.
                                <div>';
          }

          $json['success'] = true;
        }else {
          foreach ($_POST as $key => $value)
            {
              $json['alert'][$key] = form_error($key);
            }
        }

        echo json_encode($json);
    }
  }



  function delete($id)
  {
    if ($this->input->is_ajax_request()) {
      if ($this->model->get_delete($this->table,["id_contoh"=>$id])) {
        $json['alert_class'] = "alert-success";
        $json['alert'] = '<i class="fa fa-check"></i>  Berhasil Menghapus.';
      }else {
        $json['alert_class'] = "alert-danger";
        $json['alert'] = '<i class="fa fa-close"></i> Gagal Menghapus.';
      }
      echo json_encode($json);
    }
  }






} //end class
