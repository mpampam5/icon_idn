<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tb_contoh_model extends MY_Model{

  private $table = "tb_contoh";

  function json(){
    $this->datatables->select('id_contoh,nama,alamat,created_at,update_at');
    $this->datatables->from($this->table);
    $this->datatables->add_column('action',
                                  '<a href="'.site_url("backend/tb_contoh/detail/$1").'" id="detail" class="btn btn-link p-a-5 text-info" data-toggle="tooltip" data-placement="bottom" title="Detail"><i class="fa fa-file"></i></a>
                                  <a href="'.site_url("backend/tb_contoh/update/$1").'" id="update" class="btn btn-link p-a-5 text-warning" data-toggle="tooltip" data-placement="bottom" title="Edit"><i class="fa fa-pencil"></i></a>
                                  <a href="'.site_url("backend/tb_contoh/delete/$1").'" id="hapus" class="btn btn-link p-a-5 text-danger" data-toggle="tooltip" data-placement="bottom" title="Hapus"><i class="fa fa-trash"></i></a>',
                                  'id_contoh');
    return $this->datatables->generate();
  }

}
