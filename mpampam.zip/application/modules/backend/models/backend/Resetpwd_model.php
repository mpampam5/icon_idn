<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Resetpwd_model extends MY_Model 
{}